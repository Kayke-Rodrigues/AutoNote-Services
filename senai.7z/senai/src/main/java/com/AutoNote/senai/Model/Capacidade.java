package com.AutoNote.senai.Model;

import java.util.Objects;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name = "capacidade")
public class Capacidade {
	
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCapacidade;
	private TipoCapacidade tipo;
	private String nome;
	private NotaObtida notaObtida;
	private String descricaoCapacidade;

	public Capacidade() {
	}

	public Capacidade(int idCapacidade, TipoCapacidade tipo, String nome, NotaObtida notaObtida,
			String descricaoCapacidade) {
		super();
		this.idCapacidade = idCapacidade;
		this.tipo = tipo;
		this.nome = nome;
		this.notaObtida = notaObtida;
		this.descricaoCapacidade = descricaoCapacidade;
	}

	// Getters e Setters
	public int getIdCapacidade() {
		return idCapacidade;
	}

	public void setIdCapacidade(int idCapacidade) {
		this.idCapacidade = idCapacidade;
	}

	public TipoCapacidade getTipo() {
		return tipo;
	}

	public void setTipo(TipoCapacidade tipo) {
		this.tipo = tipo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public NotaObtida getNotaObtida() {
		return notaObtida;
	}

	public void setNotaObtida(NotaObtida notaObtida) {
		this.notaObtida = notaObtida;
	}

	public String getDescricaoCapacidade() {
		return descricaoCapacidade;
	}

	public void setDescricaoCapacidade(String descricaoCapacidade) {
		this.descricaoCapacidade = descricaoCapacidade;
	}

	@Override
	public int hashCode() {
		return Objects.hash(descricaoCapacidade, idCapacidade, nome, notaObtida, tipo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Capacidade other = (Capacidade) obj;
		return Objects.equals(descricaoCapacidade, other.descricaoCapacidade) && idCapacidade == other.idCapacidade
				&& Objects.equals(nome, other.nome) && notaObtida == other.notaObtida && tipo == other.tipo;
	}

	@Override
	public String toString() {
		return "Capacidade [idCapacidade=" + idCapacidade + ", tipo=" + tipo + ", nome=" + nome + ", notaObtida="
				+ notaObtida + ", descricaoCapacidade=" + descricaoCapacidade + "]";
	}

}

// Enum para o tipo de capacidade
enum TipoCapacidade {
	CRITICA, DESEJADA;
}



