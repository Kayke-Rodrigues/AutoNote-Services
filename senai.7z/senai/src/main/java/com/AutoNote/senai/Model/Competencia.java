package com.AutoNote.senai.Model;

import java.util.Objects;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Table(name = "competencia")
public class Competencia {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idCompetencia;
	private TipoCompetencia tipo;
	private String nome;
	private NotaObtida notaObtida;
	private String descricaoCompetencia;

	public Competencia() {
		super();
	}

	// Construtor
	public Competencia(int idCompetencia, TipoCompetencia tipo, String nome, NotaObtida notaObtida,
			String descricaoCompetencia) {
		super();
		this.idCompetencia = idCompetencia;
		this.tipo = tipo;
		this.nome = nome;
		this.notaObtida = notaObtida;
		this.descricaoCompetencia = descricaoCompetencia;
	}

	// Getters e Setters
	public int getIdCompetencia() {
		return idCompetencia;
	}

	public void setIdCompetencia(int idCompetencia) {
		this.idCompetencia = idCompetencia;
	}

	public TipoCompetencia getTipo() {
		return tipo;
	}

	public void setTipo(TipoCompetencia tipo) {
		this.tipo = tipo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public NotaObtida getNotaObtida() {
		return notaObtida;
	}

	public void setNotaObtida(NotaObtida notaObtida) {
		this.notaObtida = notaObtida;
	}

	public String getDescricaoCompetencia() {
		return descricaoCompetencia;
	}

	public void setDescricaoCompetencia(String descricaoCompetencia) {
		this.descricaoCompetencia = descricaoCompetencia;
	}

	@Override
	public int hashCode() {
		return Objects.hash(descricaoCompetencia, idCompetencia, nome, notaObtida, tipo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Competencia other = (Competencia) obj;
		return Objects.equals(descricaoCompetencia, other.descricaoCompetencia) && idCompetencia == other.idCompetencia
				&& Objects.equals(nome, other.nome) && notaObtida == other.notaObtida && tipo == other.tipo;
	}

	@Override
	public String toString() {
		return "Competencia [idCompetencia=" + idCompetencia + ", tipo=" + tipo + ", nome=" + nome + ", notaObtida="
				+ notaObtida + ", descricaoCompetencia=" + descricaoCompetencia + "]";
	}

}

// Enum para o tipo de competência
enum TipoCompetencia {
	TECNICA, BASICA, SOCIEMOCIONAL
}

// Enum para a nota obtida
enum NotaObtida {
	SIM, NAO, REAVALIAR
}
