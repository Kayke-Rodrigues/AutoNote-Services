package com.AutoNote.senai.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "aluno")
public class Aluno implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idAluno;
	private int matriculaAluno;
	private String cpfAluno;
	private int idTurma;

	public Aluno() {
		super();
	}

	// Construtor
	public Aluno(int idAluno, int matriculaAluno, String cpfAluno, int idTurma) {
		super();
		this.idAluno = idAluno;
		this.matriculaAluno = matriculaAluno;
		this.cpfAluno = cpfAluno;
		this.idTurma = idTurma;
	}

	// Getters e Setters
	public int getIdAluno() {
		return idAluno;
	}

	public void setIdAluno(int idAluno) {
		this.idAluno = idAluno;
	}

	public int getMatriculaAluno() {
		return matriculaAluno;
	}

	public void setMatriculaAluno(int matriculaAluno) {
		this.matriculaAluno = matriculaAluno;
	}

	public String getCpfAluno() {
		return cpfAluno;
	}

	public void setCpfAluno(String cpfAluno) {
		this.cpfAluno = cpfAluno;
	}

	public int getIdTurma() {
		return idTurma;
	}

	public void setIdTurma(int idTurma) {
		this.idTurma = idTurma;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cpfAluno, idAluno, idTurma, matriculaAluno);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aluno other = (Aluno) obj;
		return Objects.equals(cpfAluno, other.cpfAluno) && idAluno == other.idAluno && idTurma == other.idTurma
				&& matriculaAluno == other.matriculaAluno;
	}

	@Override
	public String toString() {
		return "Aluno [idAluno=" + idAluno + ", matriculaAluno=" + matriculaAluno + ", cpfAluno=" + cpfAluno
				+ ", idTurma=" + idTurma + "]";
	}

}
