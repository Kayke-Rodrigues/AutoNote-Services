package com.AutoNote.senai.entity;

import java.io.Serializable;
import java.util.Objects;

import com.AutoNote.senai.entity.Competencia.NotaObtida;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "capacidade")
public class Criterio implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idCriterio;
	private TipoCapacidade tipo;
	private String nome;
	private NotaObtida notaObtida;
	private String descricaoCapacidade;

	public Criterio() {
		super();
	}

	public Criterio(Integer idCriterio, TipoCapacidade tipo, String nome, NotaObtida notaObtida,
			String descricaoCapacidade) {
		super();
		this.idCriterio = idCriterio;
		this.tipo = tipo;
		this.nome = nome;
		this.notaObtida = notaObtida;
		this.descricaoCapacidade = descricaoCapacidade;
	}

	// Getters e Setters
	public Integer getIdCriterio() {
		return idCriterio;
	}

	public void setIdCriterio(Integer idCriterio) {
		this.idCriterio = idCriterio;
	}

	public TipoCapacidade getTipo() {
		return tipo;
	}

	public void setTipo(TipoCapacidade tipo) {
		this.tipo = tipo;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public NotaObtida getNotaObtida() {
		return notaObtida;
	}

	public void setNotaObtida(NotaObtida notaObtida) {
		this.notaObtida = notaObtida;
	}

	public String getDescricaoCapacidade() {
		return descricaoCapacidade;
	}

	public void setDescricaoCapacidade(String descricaoCapacidade) {
		this.descricaoCapacidade = descricaoCapacidade;
	}

	@Override
	public int hashCode() {
		return Objects.hash(descricaoCapacidade, idCriterio, nome, notaObtida, tipo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Criterio other = (Criterio) obj;
		return Objects.equals(descricaoCapacidade, other.descricaoCapacidade) && idCriterio == other.idCriterio
				&& Objects.equals(nome, other.nome) && notaObtida == other.notaObtida && tipo == other.tipo;
	}

	@Override
	public String toString() {
		return "idCriterio [idCriterio=" + idCriterio + ", tipo=" + tipo + ", nome=" + nome + ", notaObtida="
				+ notaObtida + ", descricaoCapacidade=" + descricaoCapacidade + "]";
	}

	// Enum para o tipo de capacidade
	enum TipoCapacidade {
		CRITICA, DESEJADA;
	}

}

