package com.AutoNote.senai.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.AutoNote.senai.entity.Criterio;

@Repository
public interface CriterioRepository extends JpaRepository<Criterio, Integer> {

	Criterio findByIdCriterio(Integer id_Criterio);

	List<Criterio> findAll();
	
	Criterio save(Criterio id_Criterio);

}