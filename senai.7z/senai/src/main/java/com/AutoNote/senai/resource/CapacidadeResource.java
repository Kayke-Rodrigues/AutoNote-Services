package com.AutoNote.senai.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.AutoNote.senai.entity.Capacidade;
import com.AutoNote.senai.repository.CapacidadeRepository;

@RestController
@RequestMapping("/upload")
public class CapacidadeResource {
	
	// Mapeamentos e escopos
	private final CapacidadeRepository capacidadeRepository;

	@Autowired
	public CapacidadeResource(CapacidadeRepository capacidadeRepository) {
		this.capacidadeRepository = capacidadeRepository;
	}

	@GetMapping("/capacidades")
	public List<Capacidade> getAll() {
		return capacidadeRepository.findAll();
	}

	@GetMapping("/capacidade")
	public Capacidade getCapacidadeById(Integer idCapacidade) {
		return capacidadeRepository.findByIdCapacidade(idCapacidade);
	}

}
