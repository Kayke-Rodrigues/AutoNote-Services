package com.AutoNote.senai.resource;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AutoNote.senai.entity.Competencia;
import com.AutoNote.senai.repository.CompetenciaRepository;

@RestController
@RequestMapping("/upload")
public class CompetenciaResource {
	
	private final CompetenciaRepository competenciaRepository;
	
	@Autowired
	public CompetenciaResource(CompetenciaRepository competenciaRepository) {
		this.competenciaRepository = competenciaRepository;
	}
	
	@GetMapping("/competencias")
	public List<Competencia> getAllCompetencia(){
		return competenciaRepository.findAll();
	}
	
	@GetMapping("/competencia")
	public Competencia getCompetenciaById(int competencia) {
		return competenciaRepository.findByIdCompetencia(competencia);
	}
	
	
}
