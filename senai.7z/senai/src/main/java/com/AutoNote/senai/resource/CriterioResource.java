package com.AutoNote.senai.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.AutoNote.senai.entity.Criterio;
import com.AutoNote.senai.repository.CriterioRepository;

@RestController
@RequestMapping("/upload")
public class CriterioResource {

	// Mapeamentos e escopos
	private final CriterioRepository criterioRepository;

	@Autowired
	public CriterioResource(CriterioRepository criterioRepository) {
		this.criterioRepository = criterioRepository;
	}

	@GetMapping("/criterios")
	public List<Criterio> getAll() {
		return criterioRepository.findAll();
	}

	@GetMapping("/criterio")
	public Criterio getCapacidadeById(Integer idCriterio) {
		return criterioRepository.findByIdCriterio(idCriterio);
	}
	
	@PostMapping("/criterio")
    public Criterio createCriterio(@RequestBody Criterio criterio) {
        return criterioRepository.save(criterio);
    }

}
