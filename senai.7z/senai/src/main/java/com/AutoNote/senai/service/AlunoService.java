package com.AutoNote.senai.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.AutoNote.senai.entity.Aluno;
import com.AutoNote.senai.repository.AlunoRepository;

@Service
public class AlunoService {

	private final AlunoRepository alunoRepository;

	@Autowired
	public AlunoService(AlunoRepository alunoRepository) {
		this.alunoRepository = alunoRepository;
	}

	// Metodo para achar todos os alunos
	public List<Aluno> findAllAlunos() {
		return alunoRepository.findAll();
	}

	public Aluno findAluno(Integer idAluno, String cpf, int matricula) {
		// Tentar encontrar o aluno diretamente pelo ID
		Aluno aluno = alunoRepository.findByIdAluno(idAluno);

		// Se achar o aluno, retorna ele
		if (aluno != null) {
			return aluno;
		}
		// Caso não ache por ID, tentara achar por cpf
		aluno = alunoRepository.findByCpfAluno(cpf);

		if (aluno != null) {
			return aluno;
		}

		// caso não ache por cpf, o procurará por matricula
		aluno = alunoRepository.findByMatriculaAluno(matricula);

		return aluno;
	}
}
