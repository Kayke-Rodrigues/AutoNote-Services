package com.AutoNote.senai.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AutoNote.senai.entity.Capacidade;
import com.AutoNote.senai.repository.CapacidadeRepository;

@Service
public class CapacidadeService {

	private final CapacidadeRepository capacidadeRepository;

	@Autowired
	public CapacidadeService(CapacidadeRepository capacidadeRepository) {
		this.capacidadeRepository = capacidadeRepository;

	}

	public List<Capacidade> findAllCapacidades() {
		return capacidadeRepository.findAll();
	}

	public Capacidade findCapacidadeById(Integer idCapacidade) {
		Capacidade capacidade = capacidadeRepository.findByIdCapacidade(idCapacidade);
		return capacidade;
	}
}
