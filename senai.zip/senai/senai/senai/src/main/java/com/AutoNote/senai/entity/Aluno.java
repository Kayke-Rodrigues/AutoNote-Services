package com.AutoNote.senai.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "aluno")
public class Aluno implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private Integer num_matricula_aluno;
	private Date data_inicio_aluno;
	private String cpf_aluno;
	private String email_aluno;

	public Aluno(Integer num_matricula_aluno, Date data_inicio_aluno, String cpf_aluno, String email_aluno) {
		super();
		this.num_matricula_aluno = num_matricula_aluno;
		this.data_inicio_aluno = data_inicio_aluno;
		this.cpf_aluno = cpf_aluno;
		this.email_aluno = email_aluno;
	}

	public Aluno() {
		super();
	}

	public Integer getNum_matricula_aluno() {
		return num_matricula_aluno;
	}

	public void setNum_matricula_aluno(Integer num_matricula_aluno) {
		this.num_matricula_aluno = num_matricula_aluno;
	}

	public Date getData_inicio_aluno() {
		return data_inicio_aluno;
	}

	public void setData_inicio_aluno(Date data_inicio_aluno) {
		this.data_inicio_aluno = data_inicio_aluno;
	}

	public String getCpf_aluno() {
		return cpf_aluno;
	}

	public void setCpf_aluno(String cpf_aluno) {
		this.cpf_aluno = cpf_aluno;
	}

	public String getEmail_aluno() {
		return email_aluno;
	}

	public void setEmail_aluno(String email_aluno) {
		this.email_aluno = email_aluno;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cpf_aluno, data_inicio_aluno, email_aluno, num_matricula_aluno);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aluno other = (Aluno) obj;
		return Objects.equals(cpf_aluno, other.cpf_aluno) && Objects.equals(data_inicio_aluno, other.data_inicio_aluno)
				&& Objects.equals(email_aluno, other.email_aluno)
				&& Objects.equals(num_matricula_aluno, other.num_matricula_aluno);
	}

	@Override
	public String toString() {
		return "Aluno [num_matricula_aluno=" + num_matricula_aluno + ", data_inicio_aluno=" + data_inicio_aluno
				+ ", cpf_aluno=" + cpf_aluno + ", email_aluno=" + email_aluno + "]";
	}

}