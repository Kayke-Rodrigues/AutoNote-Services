package com.AutoNote.senai.entity;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "capacidade")
public class Criterio implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id_Criterio;
	private int num_matricula_aluno;
	private int id_competencia;
	@Column(name = "tipo")
	private TipoCriticidades tipoCriticidades;
	private String nome;
	private Avaliado avaliado;
	private String descricao;

	public Criterio() {
		super();
	}

	public Criterio(Integer id_Criterio, int num_matricula_aluno, int id_competencia, TipoCriticidades tipoCriticidades,
			String nome, Avaliado avaliado, String descricao) {
		super();
		this.id_Criterio = id_Criterio;
		this.num_matricula_aluno = num_matricula_aluno;
		this.id_competencia = id_competencia;
		this.tipoCriticidades = tipoCriticidades;
		this.nome = nome;
		this.avaliado = avaliado;
		this.descricao = descricao;
	}

	public Integer getId_Criterio() {
		return id_Criterio;
	}

	public void setId_Criterio(Integer id_Criterio) {
		this.id_Criterio = id_Criterio;
	}

	public int getNum_matricula_aluno() {
		return num_matricula_aluno;
	}

	public void setNum_matricula_aluno(int num_matricula_aluno) {
		this.num_matricula_aluno = num_matricula_aluno;
	}

	public int getId_competencia() {
		return id_competencia;
	}

	public void setId_competencia(int id_competencia) {
		this.id_competencia = id_competencia;
	}

	public TipoCriticidades getTipoCriticidades() {
		return tipoCriticidades;
	}

	public void setTipoCriticidades(TipoCriticidades tipoCriticidades) {
		this.tipoCriticidades = tipoCriticidades;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Avaliado getAvaliado() {
		return avaliado;
	}

	public void setAvaliado(Avaliado avaliado) {
		this.avaliado = avaliado;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		return Objects.hash(avaliado, descricao, id_Criterio, id_competencia, nome, num_matricula_aluno,
				tipoCriticidades);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Criterio other = (Criterio) obj;
		return avaliado == other.avaliado && Objects.equals(descricao, other.descricao)
				&& Objects.equals(id_Criterio, other.id_Criterio) && id_competencia == other.id_competencia
				&& Objects.equals(nome, other.nome) && num_matricula_aluno == other.num_matricula_aluno
				&& tipoCriticidades == other.tipoCriticidades;
	}

	@Override
	public String toString() {
		return "Criterio [id_Criterio=" + id_Criterio + ", num_matricula_aluno=" + num_matricula_aluno
				+ ", id_competencia=" + id_competencia + ", tipoCriticidades=" + tipoCriticidades + ", nome=" + nome
				+ ", avaliado=" + avaliado + ", descricao=" + descricao + "]";
	}

	enum Avaliado {
		sim, nao, avaliar
	}

	enum TipoCriticidades {
		critica, desejada
	}
}
