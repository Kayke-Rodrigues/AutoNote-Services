package com.AutoNote.senai.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AutoNote.senai.entity.Aluno;

@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Integer> {

	Aluno findByIdAluno(Integer num_matricula_aluno);

	List<Aluno> findAll();

	Aluno findByCpfAluno(String cpf_aluno);


}
