package com.AutoNote.senai.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AutoNote.senai.entity.Competencia;

@Repository
public interface CompetenciaRepository extends JpaRepository<Competencia, Integer> {
	
	//criação do metodo de puxar a competencia (o próprio spring entende a linha
	//e a transforma numa QUERY no Banco de Dados
	Competencia findByIdCompetencia(int id_Competencia);
	
	List<Competencia> findAllByCompetencia();
}
	
