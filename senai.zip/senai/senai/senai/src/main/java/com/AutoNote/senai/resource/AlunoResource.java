package com.AutoNote.senai.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AutoNote.senai.entity.Aluno;
import com.AutoNote.senai.repository.AlunoRepository;

@RestController
@RequestMapping("/upload")
public class AlunoResource {

	// Mapeamentos e escopos
	private final AlunoRepository alunoRepository;

	@Autowired
	public AlunoResource(AlunoRepository alunoRepository) {
		this.alunoRepository = alunoRepository;
	}

	@GetMapping("/alunos")
	public List<Aluno> getAllAlunos() {
		return alunoRepository.findAll();
	}

	@GetMapping("/aluno")
	public Aluno getAlunoById(Integer num_matricula_aluno) {
		return alunoRepository.findByIdAluno(num_matricula_aluno);
	}
}
