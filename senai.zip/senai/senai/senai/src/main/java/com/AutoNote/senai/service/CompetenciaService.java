package com.AutoNote.senai.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.AutoNote.senai.entity.Competencia;
import com.AutoNote.senai.repository.CompetenciaRepository;


@Service
public class CompetenciaService {

	private final CompetenciaRepository competenciaRepository;

	@Autowired
	public CompetenciaService(CompetenciaRepository competenciaRepository) {
		this.competenciaRepository = competenciaRepository;
	}

	// Este é o metodo para puxar todas as competencias
	public List<Competencia> findAllByCompetencia() {
		return competenciaRepository.findAll();
	}

	public Competencia findCompetenciaById(int id_Competencia) {
		Competencia competencia = competenciaRepository.findByIdCompetencia(id_Competencia);
		return competencia;
	}
}
