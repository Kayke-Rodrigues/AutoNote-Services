package com.AutoNote.senai.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.AutoNote.senai.entity.Criterio;
import com.AutoNote.senai.repository.CriterioRepository;

@Service
public class CriterioService {

	private final CriterioRepository criterioRepository;

	@Autowired
	public CriterioService(CriterioRepository criterioRepository) {
		this.criterioRepository = criterioRepository;

	}

	public List<Criterio> findAllCapacidades() {
		return criterioRepository.findAll();
	}

	public Criterio findCapacidadeById(Integer idCriterio) {
		Criterio criterio = criterioRepository.findByIdCriterio(idCriterio);
		return criterio;
	}

	public Criterio saveCriterio(Criterio criterio) {
		return criterioRepository.save(criterio);
	}

}
